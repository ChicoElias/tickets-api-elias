Tickets API – Fullstack II (Clase 1 + Clase 2)

Proyecto backend en Spring Boot para gestionar tickets de incidencias TI en una institución educativa.
Incluye CRUD completo, paginación, filtros avanzados y un endpoint de reporte usando JDBC.

Para ejecutar:
1. Importar como proyecto Gradle en IntelliJ IDEA.
2. Ejecutar la clase cl.duoc.elias.delgado.ticketsapi.TicketsApiApplication.
3. Probar la API en http://localhost:8081.

Endpoints principales:
- POST /api/tickets
- GET /api/tickets/all
- GET /api/tickets (paginación + filtros)
- GET /api/tickets/{id}
- PUT /api/tickets/{id}
- DELETE /api/tickets/{id}
- GET /api/reports/tickets-by-status
