package cl.duoc.elias.delgado.ticketsapi.ticket.service;

import cl.duoc.elias.delgado.ticketsapi.ticket.dto.TicketDTO;
import cl.duoc.elias.delgado.ticketsapi.ticket.filter.TicketFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface TicketService {

    TicketDTO create(TicketDTO dto);

    TicketDTO findById(Long id);

    List<TicketDTO> findAll();

    Page<TicketDTO> findTickets(TicketFilter filter, Pageable pageable);

    TicketDTO update(Long id, TicketDTO dto);

    void delete(Long id);
}
