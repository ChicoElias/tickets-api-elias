package cl.duoc.elias.delgado.ticketsapi.ticket.filter;

import cl.duoc.elias.delgado.ticketsapi.ticket.model.TicketStatus;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class TicketFilter {

    private TicketStatus status;
    private String categoria;
    private LocalDateTime from;
    private LocalDateTime to;
}
