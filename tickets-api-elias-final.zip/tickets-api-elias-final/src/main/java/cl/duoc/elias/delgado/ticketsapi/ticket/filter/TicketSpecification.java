package cl.duoc.elias.delgado.ticketsapi.ticket.filter;

import cl.duoc.elias.delgado.ticketsapi.ticket.model.Ticket;
import cl.duoc.elias.delgado.ticketsapi.ticket.model.TicketStatus;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDateTime;

public class TicketSpecification {

    public static Specification<Ticket> hasStatus(TicketStatus status) {
        return (root, query, cb) ->
                status == null ? null : cb.equal(root.get("estado"), status);
    }

    public static Specification<Ticket> hasCategoria(String categoria) {
        return (root, query, cb) ->
                categoria == null ? null :
                        cb.like(cb.lower(root.get("categoria")), "%" + categoria.toLowerCase() + "%");
    }

    public static Specification<Ticket> createdAfter(LocalDateTime from) {
        return (root, query, cb) ->
                from == null ? null : cb.greaterThanOrEqualTo(root.get("createdAt"), from);
    }

    public static Specification<Ticket> createdBefore(LocalDateTime to) {
        return (root, query, cb) ->
                to == null ? null : cb.lessThanOrEqualTo(root.get("createdAt"), to);
    }

    public static Specification<Ticket> notDeleted() {
        return (root, query, cb) ->
                cb.isFalse(root.get("deleted"));
    }
}
