package cl.duoc.elias.delgado.ticketsapi.ticket.model;

public enum TicketStatus {
    OPEN,
    IN_PROGRESS,
    CLOSED
}
