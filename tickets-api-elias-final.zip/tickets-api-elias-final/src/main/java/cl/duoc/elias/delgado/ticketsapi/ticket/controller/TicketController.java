package cl.duoc.elias.delgado.ticketsapi.ticket.controller;

import cl.duoc.elias.delgado.ticketsapi.ticket.dto.TicketDTO;
import cl.duoc.elias.delgado.ticketsapi.ticket.filter.TicketFilter;
import cl.duoc.elias.delgado.ticketsapi.ticket.model.TicketStatus;
import cl.duoc.elias.delgado.ticketsapi.ticket.service.TicketService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/tickets")
@CrossOrigin(origins = "*")
public class TicketController {

    private final TicketService ticketService;

    public TicketController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @PostMapping
    public ResponseEntity<TicketDTO> create(@RequestBody TicketDTO dto) {
        return ResponseEntity.ok(ticketService.create(dto));
    }

    @GetMapping("/all")
    public ResponseEntity<List<TicketDTO>> findAll() {
        return ResponseEntity.ok(ticketService.findAll());
    }

    @GetMapping
    public ResponseEntity<Page<TicketDTO>> findTickets(
            @RequestParam(required = false) TicketStatus status,
            @RequestParam(required = false) String categoria,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime from,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime to,
            Pageable pageable
    ) {
        TicketFilter filter = TicketFilter.builder()
                .status(status)
                .categoria(categoria)
                .from(from)
                .to(to)
                .build();

        return ResponseEntity.ok(ticketService.findTickets(filter, pageable));
    }

    @GetMapping("/{id}")
    public ResponseEntity<TicketDTO> findById(@PathVariable Long id) {
        return ResponseEntity.ok(ticketService.findById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TicketDTO> update(@PathVariable Long id, @RequestBody TicketDTO dto) {
        return ResponseEntity.ok(ticketService.update(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        ticketService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
