package cl.duoc.elias.delgado.ticketsapi.ticket.model;

public enum TicketPriority {
    LOW,
    MEDIUM,
    HIGH
}
